# InsightFlow AI — starter app

A beginner-friendly React + Vite starter for spreadsheet analysis. The first version runs in the browser and does not require AWS credentials or a backend.

## Features
- Upload a CSV file and preview its rows
- Basic data quality checks: row count, columns, missing cells and duplicate rows
- Search across uploaded rows
- Download a cleaned CSV (fully empty rows removed)
- Simple chart for the first numeric column
- Sample dataset when no file has been uploaded

## Run locally
Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal.

## Deploy with AWS Amplify
1. Push these files to a GitHub repository.
2. In AWS Amplify, connect that repository and select the branch.
3. Use these build settings:
   - Build command: `npm run build`
   - Build output directory: `dist`
4. The included `amplify.yml` contains the same settings, so Amplify may detect them automatically.

## Current limitations
- This is a frontend prototype. Data is processed in the browser and is not saved to an online database.
- No sign-in, team collaboration, document classification or generative AI integration is included yet.
- CSV upload is supported in this starter. Excel `.xlsx` support can be added in a later stage.
- Do not upload confidential or sensitive business data to a prototype without a suitable security review.
- AI features may incur provider charges and are intentionally not enabled in this starter.
