import { useMemo, useRef, useState } from 'react'
import Papa from 'papaparse'
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'

const sampleRows = [
  { Date: '2026-01-05', Product: 'Notebook', Category: 'Stationery', Sales: '1250', Region: 'North' },
  { Date: '2026-01-08', Product: 'Pen Set', Category: 'Stationery', Sales: '820', Region: 'West' },
  { Date: '2026-01-12', Product: 'Desk Lamp', Category: 'Office', Sales: '2450', Region: 'South' },
  { Date: '2026-01-17', Product: 'Notebook', Category: 'Stationery', Sales: '980', Region: 'East' },
  { Date: '2026-01-20', Product: 'File Organizer', Category: 'Office', Sales: '1640', Region: 'North' },
  { Date: '2026-01-23', Product: 'Pen Set', Category: 'Stationery', Sales: '740', Region: 'West' },
  { Date: '2026-01-26', Product: 'Desk Lamp', Category: 'Office', Sales: '2890', Region: 'South' },
]

const initialData = sampleRows
const currency = (n) => new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(n)

function Icon({ name, size = 18 }) {
  const paths = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></>,
    chart: <><path d="M3 3v18h18"/><path d="m7 14 4-4 3 3 6-7"/></>,
    file: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/></>,
    spark: <><path d="m12 3 1.9 5.8L20 11l-6.1 2.2L12 19l-2-5.8L4 11l6-2.2z"/><path d="m19 14 1.1 2.1L22 17l-1.9.9L19 20l-1-2.1-2-.9 2-.9z"/></>,
    upload: <><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5M12 3v12"/></>,
    download: <><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    check: <><path d="m5 12 4 4L19 6"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    menu: <><path d="M4 6h16M4 12h16M4 18h16"/></>,
    database: <><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></>,
    warning: <><path d="m10.3 3.9-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.7-3.1l-8-14a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></>,
  }
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] || paths.grid}</svg>
}

function App() {
  const [rows, setRows] = useState(initialData)
  const [columns, setColumns] = useState(Object.keys(initialData[0]))
  const [fileName, setFileName] = useState('Sample sales data')
  const [search, setSearch] = useState('')
  const [active, setActive] = useState('Overview')
  const [notice, setNotice] = useState('')
  const fileRef = useRef(null)

  const numericColumn = useMemo(() => columns.find((col) => {
    const values = rows.map((r) => r[col]).filter((v) => v !== '' && v != null)
    return values.length > 0 && values.every((v) => Number.isFinite(Number(v)))
  }), [columns, rows])

  const metrics = useMemo(() => {
    const allCells = rows.flatMap((r) => columns.map((c) => r[c]))
    const missing = allCells.filter((v) => v == null || String(v).trim() === '').length
    const seen = new Set()
    let duplicates = 0
    rows.forEach((r) => {
      const key = JSON.stringify(columns.map((c) => r[c] ?? ''))
      if (seen.has(key)) duplicates += 1
      else seen.add(key)
    })
    const numericValues = numericColumn ? rows.map((r) => Number(r[numericColumn])).filter(Number.isFinite) : []
    const total = numericValues.reduce((a, b) => a + b, 0)
    return { rowCount: rows.length, columnCount: columns.length, missing, duplicates, total }
  }, [rows, columns, numericColumn])

  const chartData = useMemo(() => rows.slice(0, 14).map((row, index) => ({
    name: String(row[columns[0]] ?? `Row ${index + 1}`).slice(0, 16),
    value: numericColumn ? Number(row[numericColumn]) || 0 : index + 1,
  })), [rows, columns, numericColumn])

  const visibleRows = useMemo(() => {
    const term = search.toLowerCase().trim()
    if (!term) return rows.slice(0, 100)
    return rows.filter((row) => columns.some((col) => String(row[col] ?? '').toLowerCase().includes(term))).slice(0, 100)
  }, [rows, columns, search])

  function handleFile(file) {
    if (!file) return
    if (!file.name.toLowerCase().endsWith('.csv')) {
      setNotice('Please upload a CSV file. Excel support can be added in a later version.')
      return
    }
    if (file.size > 10 * 1024 * 1024) {
      setNotice('This starter accepts CSV files up to 10 MB.')
      return
    }
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header) => header.trim(),
      complete: (result) => {
        const parsedRows = result.data.filter((r) => Object.values(r).some((v) => String(v ?? '').trim() !== ''))
        const parsedColumns = result.meta.fields || Object.keys(parsedRows[0] || {})
        if (!parsedColumns.length || !parsedRows.length) {
          setNotice('No usable rows were found. Please check the CSV file and try again.')
          return
        }
        setRows(parsedRows)
        setColumns(parsedColumns)
        setFileName(file.name)
        setSearch('')
        setActive('Data Explorer')
        setNotice(result.errors.length ? `Imported with ${result.errors.length} parsing warning(s). Please review your data.` : `Successfully imported ${parsedRows.length} rows from ${file.name}.`)
      },
      error: () => setNotice('We could not read that file. Please try another CSV file.'),
    })
  }

  function downloadCsv(data, name = 'insightflow-cleaned.csv') {
    if (!data.length) {
      setNotice('There is no data to download.')
      return
    }
    const csv = Papa.unparse(data)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = name
    document.body.appendChild(link)
    link.click()
    link.remove()
    URL.revokeObjectURL(url)
    setNotice(`Downloaded ${name}.`)
  }

  function cleanData() {
    const cleaned = rows.filter((r) => columns.some((c) => String(r[c] ?? '').trim() !== ''))
    const seen = new Set()
    const unique = cleaned.filter((r) => {
      const key = JSON.stringify(columns.map((c) => r[c] ?? ''))
      if (seen.has(key)) return false
      seen.add(key)
      return true
    })
    setRows(unique)
    setNotice(`Removed ${cleaned.length - unique.length} duplicate or empty row(s). Original uploaded file is unchanged.`)
  }

  const nav = [
    { name: 'Overview', icon: 'grid' },
    { name: 'Data Explorer', icon: 'database' },
    { name: 'Spreadsheet Analysis', icon: 'chart' },
    { name: 'AI Assistant', icon: 'spark' },
    { name: 'Document Classifier', icon: 'file' },
  ]

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Icon name="chart" size={22}/></div>
          <div><strong>InsightFlow<span> AI</span></strong><small>DATA WORKSPACE</small></div>
        </div>
        <div className="workspace-switch"><div className="workspace-avatar">IF</div><div><b>My workspace</b><small>Personal account</small></div><span className="chevron">⌄</span></div>
        <div className="nav-label">WORKSPACE</div>
        <nav>
          {nav.map((item) => <button key={item.name} className={`nav-item ${active === item.name ? 'active' : ''}`} onClick={() => setActive(item.name)}><Icon name={item.icon}/><span>{item.name}</span>{item.name === 'AI Assistant' && <span className="soon">Soon</span>}</button>)}
        </nav>
        <div className="sidebar-bottom">
          <div className="plan-card"><div className="plan-icon"><Icon name="spark"/></div><b>Your data, clearer.</b><p>Turn spreadsheets into decisions with simple analytics tools.</p><span className="local-badge"><span/> Browser-based prototype</span></div>
          <div className="profile"><div className="profile-avatar">U</div><div><b>Your account</b><small>Starter workspace</small></div><span className="dots">•••</span></div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="breadcrumb"><span>Workspace</span><span className="slash">/</span><b>{active}</b></div>
          <div className="top-actions"><span className="status-pill"><span/> All systems local</span><button className="avatar-button" title="Profile">U</button></div>
        </header>
        <div className="content">
          <div className="page-heading">
            <div><div className="eyebrow">MONDAY, YOUR DATA DAY</div><h1>{active === 'Overview' ? 'Good insights start here.' : active}</h1><p>{active === 'Overview' ? 'Your data workspace at a glance. Upload a file to start exploring.' : 'Explore your dataset and find useful patterns in a few steps.'}</p></div>
            <button className="primary-button" onClick={() => fileRef.current?.click()}><Icon name="upload" size={17}/> Upload CSV</button>
            <input ref={fileRef} type="file" accept=".csv,text/csv" hidden onChange={(e) => { handleFile(e.target.files?.[0]); e.target.value = '' }}/>
          </div>

          {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={() => setNotice('')} aria-label="Dismiss message">×</button></div>}

          {active === 'AI Assistant' || active === 'Document Classifier' ? (
            <div className="coming-panel"><div className="coming-icon"><Icon name={active === 'AI Assistant' ? 'spark' : 'file'} size={28}/></div><span className="coming-label">PLANNED MODULE</span><h2>{active === 'AI Assistant' ? 'Your data copilot is on the roadmap.' : 'Document classification is coming next.'}</h2><p>{active === 'AI Assistant' ? 'The next stage can add natural-language questions about uploaded datasets. This starter does not send data to an AI provider.' : 'The next stage can add document upload, classification categories and reviewable extraction results.'}</p><div className="coming-note"><Icon name="warning" size={17}/> This screen is a placeholder, not a working AI integration.</div></div>
          ) : (
            <>
              <div className="metrics-grid">
                <Metric label="Rows in dataset" value={currency(metrics.rowCount)} hint="Records loaded" icon="database" tone="purple"/>
                <Metric label="Columns detected" value={currency(metrics.columnCount)} hint="Fields available" icon="grid" tone="blue"/>
                <Metric label="Missing cells" value={currency(metrics.missing)} hint={metrics.missing ? 'Review recommended' : 'No empty cells found'} icon="warning" tone="amber"/>
                <Metric label="Duplicate rows" value={currency(metrics.duplicates)} hint={metrics.duplicates ? 'Potential duplicates' : 'No duplicates found'} icon="check" tone="green"/>
              </div>

              <div className="section-grid">
                <section className="panel chart-panel">
                  <div className="panel-heading"><div><h2>Data overview</h2><p>{numericColumn ? `Showing ${numericColumn} across the first ${Math.min(rows.length, 14)} rows` : 'Preview of records in your dataset'}</p></div><span className="mini-tag"><span/> LIVE PREVIEW</span></div>
                  <div className="chart-total"><strong>{numericColumn ? currency(metrics.total) : currency(rows.length)}</strong><span>{numericColumn ? `Total ${numericColumn}` : 'Rows loaded'}</span></div>
                  <div className="chart-wrap">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                        <defs><linearGradient id="flowGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#7667f8" stopOpacity={0.26}/><stop offset="95%" stopColor="#7667f8" stopOpacity={0.01}/></linearGradient></defs>
                        <CartesianGrid stroke="#edf0f6" strokeDasharray="4 4" vertical={false}/>
                        <XAxis dataKey="name" tick={{ fill: '#8b93a5', fontSize: 11 }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fill: '#8b93a5', fontSize: 11 }} axisLine={false} tickLine={false}/>
                        <Tooltip contentStyle={{ border: '1px solid #e7eaf1', borderRadius: 12, fontSize: 12 }} />
                        <Area type="monotone" dataKey="value" stroke="#7667f8" strokeWidth={2.5} fill="url(#flowGradient)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="chart-footer"><span><i className="legend-dot"/> {numericColumn || 'Row count'}</span><span>First {Math.min(rows.length, 14)} rows</span></div>
                </section>

                <section className="panel quality-panel">
                  <div className="panel-heading"><div><h2>Data quality</h2><p>A quick health check of your dataset</p></div><div className="quality-ring"><Icon name="check" size={19}/></div></div>
                  <div className="quality-score">{Math.max(0, Math.round(100 * (1 - (metrics.missing + metrics.duplicates) / Math.max(1, rows.length * Math.max(1, columns.length)))))}<span>/100</span></div>
                  <p className="score-caption">Estimated completeness score</p>
                  <div className="quality-list">
                    <QualityRow label="Missing values" value={metrics.missing} tone="amber"/>
                    <QualityRow label="Duplicate rows" value={metrics.duplicates} tone="purple"/>
                    <QualityRow label="Records analysed" value={rows.length} tone="green"/>
                  </div>
                  <button className="secondary-button full-button" onClick={cleanData}>Remove empty & duplicate rows <span>→</span></button>
                </section>
              </div>

              <section className="panel data-panel">
                <div className="panel-heading data-heading"><div><h2>Dataset preview</h2><p>{fileName} <span className="file-type">CSV / SAMPLE</span></p></div><div className="data-actions"><label className="search-box"><Icon name="search" size={16}/><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search records..." /></label><button className="icon-button" title="Download current data" onClick={() => downloadCsv(rows)}><Icon name="download"/></button></div></div>
                <div className="table-scroll"><table><thead><tr><th className="row-number">#</th>{columns.slice(0, 7).map((col) => <th key={col}>{col}</th>)}</tr></thead><tbody>
                  {visibleRows.slice(0, 8).map((row, index) => <tr key={`${index}-${JSON.stringify(row)}`}><td className="row-number">{index + 1}</td>{columns.slice(0, 7).map((col) => <td key={col}>{row[col] == null || row[col] === '' ? <span className="empty-cell">Empty</span> : String(row[col])}</td>)}</tr>)}
                  {!visibleRows.length && <tr><td colSpan={Math.min(columns.length, 7) + 1} className="empty-state">No rows match your search.</td></tr>}
                </tbody></table></div>
                <div className="table-footer"><span>Showing {Math.min(visibleRows.length, 8)} of {visibleRows.length} matching rows (maximum 100 loaded in preview)</span><button className="text-button" onClick={() => setActive('Data Explorer')}>Explore dataset <span>→</span></button></div>
              </section>
              <div className="bottom-note"><Icon name="shield-check" size={16}/><span><b>Privacy first:</b> this starter processes your CSV in your browser. Files are not uploaded to a server or saved online.</span></div>
            </>
          )}
          <footer>InsightFlow AI <span>•</span> Starter prototype <span>•</span> Built for clearer decisions</footer>
        </div>
      </main>
    </div>
  )
}

function Metric({ label, value, hint, icon, tone }) {
  return <section className="metric-card"><div className={`metric-icon ${tone}`}><Icon name={icon} size={19}/></div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-hint">{hint}</div><div className={`metric-spark ${tone}`}><span/><span/><span/><span/><span/><span/><span/><span/></div></section>
}
function QualityRow({ label, value, tone }) {
  return <div className="quality-row"><span className={`quality-dot ${tone}`}/><span>{label}</span><b>{value}</b></div>
}

export default App
